<div class="container mt-5">

    <div class="card mx-auto mt-5" style="max-width: 600px;">
        <div class="card-body">
            <form action="<?php echo e(route('rutaconfirmaenvio')); ?>" method="POST" class="form-container w-100">
                <?php echo csrf_field(); ?>
                <h1 class="text-center"><?php echo e($titulo); ?></h1>
                <div class="form-group">
                    <label for="isbn">ISBN:</label>
                    <input type="text" name="txtisbn" value="<?php echo e(old('txtisbn')); ?>" class="form-control">
                    <small class="text-danger fst-italic"><?php echo e($errors->first('txtisbn')); ?></small>
                </div>
                <div class="form-group">
                    <label for="titulo"><?php echo e(__('Titulo')); ?>:</label>
                    <input type="text" name="txttitulo" value="<?php echo e(old('txttitulo')); ?>" class="form-control">
                    <small class="text-danger fst-italic"><?php echo e($errors->first('txttitulo')); ?></small>
                </div>
                <div class="form-group">
                    <label for="autor"><?php echo e(__('Autor')); ?>:</label>
                    <input type="text" name="txtautor" value="<?php echo e(old('txtautor')); ?>" class="form-control">
                    <small class="text-danger fst-italic"><?php echo e($errors->first('txtautor')); ?></small>
                </div>
                <div class="form-group">
                    <label for="paginas"><?php echo e(__('Paginas')); ?>:</label>
                    <input type="number" name="txtpaginas" value="<?php echo e(old('txtpaginas')); ?>" class="form-control">
                    <small class="text-danger fst-italic"><?php echo e($errors->first('txtpaginas')); ?></small>
                </div>
                <div class="form-group">
                    <label for="año"><?php echo e(__('Año')); ?>:</label>
                    <input type="number" name="txtaño" value="<?php echo e(old('txtaño')); ?>" class="form-control">
                    <small class="text-danger fst-italic"><?php echo e($errors->first('txtaño')); ?></small>
                </div>
                <div class="form-group">
                    <label for="editorial"><?php echo e(__('Editorial')); ?>:</label>
                    <input type="text" name="txteditorial" value="<?php echo e(old('txteditorial')); ?>" class="form-control">
                    <small class="text-danger fst-italic"><?php echo e($errors->first('txteditorial')); ?></small>
                </div>
                <div class="form-group">
                    <label for="email_editorial"><?php echo e(__('Email de')); ?>Email de Editorial:</label>
                    <input type="email" name="txtemail" value="<?php echo e(old('txtemail')); ?>" class="form-control">
                    <small class="text-danger fst-italic"><?php echo e($errors->first('txtemail')); ?></small>
                </div>
                <button type="submit" class="btn btn-success w-100"><?php echo e($boton); ?></button>
            </form>
        </div>
    </div>
</div>
<?php if(session('success')): ?>
    <script>
        alertify.success('Todo correcto: Libro "<?php echo e(session('success')); ?>" guardado');
    </script>
<?php endif; ?><?php /**PATH C:\laragon\www\s191pw\Repaso2\resources\views/components/card.blade.php ENDPATH**/ ?>