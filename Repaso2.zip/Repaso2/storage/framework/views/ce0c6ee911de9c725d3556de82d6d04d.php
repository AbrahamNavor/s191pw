

<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('contenido'); ?>

   <div class="container mt-5 text-center">
        <h1><?php echo e(__('Noticia Literaria')); ?></h1>
        <p><?php echo e(__('El Día de las Bibliotecas se celebra cada 24 de octubre desde el año 1997. Este día nació como iniciativa de la Asociación
             Española de Amigos del Libro Infantil y Juvenil con el objetivo de concienciar a la sociedad de la importancia de la lectura
              y como homenaje y reconocimiento a la labor de los bibliotecarios/as.')); ?></p>
              <img alt="imagen aleatoria" src="https://picsum.photos/700/400?random">
    </div>
    <div class="d-flex justify-content-center">
        <a href="<?php echo e(route('rutaregistro')); ?>" class="btn btn-success mt-3 w-50 text-center"><?php echo e(__('Ir a Registro')); ?></a>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\s191pw\Repaso2\resources\views/inicio.blade.php ENDPATH**/ ?>