@extends('layouts.plantilla')

@section('title', 'Registro')

@section('contenido')

<x-card titulo="{{ __('Registro de Libros') }}" boton="{{ __('Registrar') }}"></x-card>

@endsection